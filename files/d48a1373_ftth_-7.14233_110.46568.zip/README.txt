FTTH AS-Plan Drawing
Generated: -7.14233, 110.46568  radius=300.0m

Files:
  ftth_-7.14233_110.46568.dxf  — CAD drawing (BANGUNAN / JALAN / SATELIT layers)
  satellite_-7.14233_110.46568.png  — Google satellite underlay image

IMPORTANT: Keep both files in the same folder when opening the DXF.
Layer order: SATELIT (bottom) → JALAN → BANGUNAN (top)
